package com.wipro.pan.bean;

import java.util.Date;

public class PANBean 
{
	
	String panid;
	String name;
	String location;
	String phno;
	Date request_date;
	Date dispatch_date;

	
	public String getPanid() {
		return panid;
	}
	public void setPanid(String panid) {
		this.panid = panid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	public Date getRequest_date() {
		return request_date;
	}
	public void setRequest_date(Date request_date) {
		this.request_date = request_date;
	}
	public Date getDispatch_date() {
		return dispatch_date;
	}
	public void setDispatch_date(Date dispatch_date) {
		this.dispatch_date = dispatch_date;
	}
	

}
