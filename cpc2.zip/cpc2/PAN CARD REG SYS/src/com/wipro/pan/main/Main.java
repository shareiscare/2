package com.wipro.pan.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.wipro.pan.bean.PANBean;
import com.wipro.pan.service.Administrator;

public class Main {

	public static void main(String[] args)
	{
		
		Administrator a = new Administrator();
		PANBean p = new PANBean();
		/*p. setName(�HariPrasath�);
		p.setLocation(�Chennai�);
		p.setphno(�9789198747�);
		p. setRequest_date(new Date());*/
		
		p.setName("HariPradesh");
		p.setLocation("Chennai");
		p.setPhno("819538130");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		java.util.Date date= null;
		try {
			date = sdf.parse("10/08/");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(date);
		p.setRequest_date(date);
		
		String stat=a.newRequest(p);
		System.out.println(stat);

	}

}
