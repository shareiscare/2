package com.wipro.pan.dao;

import java.util.Date;

import com.wipro.pan.bean.PANBean;

public class PanDAO 
{

	
	
	
	public String processRequest(PANBean panBean)
	{
		return null;
	}
	
	
	public String genPANID(String location, int phone_no)
	{
		return null;
	}
	
	
	public Date genDispatchDate(Date RequestDate)
	{
		return null;
	}
	
}
