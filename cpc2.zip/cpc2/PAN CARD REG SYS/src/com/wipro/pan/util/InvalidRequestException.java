package com.wipro.pan.util;

public class InvalidRequestException extends Exception
{

	@Override
	public String toString() {
		
		return "Invalid Request";
	}
	
}
