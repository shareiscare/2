package com.wipro.pan.util;

import java.sql.Connection;

public class DBUtil 
{

	public static Connection getDatabaseConnectivity()
	{
		return null;
	}
	
}
