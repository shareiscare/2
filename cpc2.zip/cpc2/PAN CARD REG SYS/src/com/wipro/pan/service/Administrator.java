package com.wipro.pan.service;

import java.util.Date;

import com.wipro.pan.bean.PANBean;
import com.wipro.pan.util.InvalidRequestException;

public class Administrator 
{

	
	
	public String newRequest(PANBean panBean)
	{	
		
		String res = "";
		/*
		Get the PAN Bean Object and throw InvalidRequestException if any of the following condition satisfied
		a. panBean null
		b. location null
		c. requestDate null
		d. name null*/
		
		
		try {
			if(panBean==null || panBean.getLocation()==null || panBean.getRequest_date()==null || panBean.getName()==null)
			{
				throw new InvalidRequestException();
			}
		} catch (InvalidRequestException e) {
			
			System.out.println(e);
		}
		
		
		/*2. the date of request should be the current date, if it is not the current date return �Invalid Date�
		3. The length of phone number should be exactly 10. Else return �Invalid PhoneNo�
		*/
		System.out.println(panBean.getRequest_date());
		System.out.println(new Date().toString());
		
		if(!(panBean.getRequest_date().toString().equals(new Date().toString())))
		{
			res = "Invalid Date";
		}else if(panBean.getPhno().length()!=10)
		{
			res = "Invalid PhoneNo";
		}
		
	return res;	
	}

}
