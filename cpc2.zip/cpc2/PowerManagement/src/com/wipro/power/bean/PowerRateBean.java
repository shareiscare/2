package com.wipro.power.bean;

public class PowerRateBean {
	private String type;
	private int slab1;
	private int slab2;
	private int slab3;
	private float slab1rate;
	private float slab2rate;
	private float slab3rate;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public int getSlab1() {
		return slab1;
	}
	public void setSlab1(int slab1) {
		this.slab1 = slab1;
	}
	public int getSlab2() {
		return slab2;
	}
	public void setSlab2(int slab2) {
		this.slab2 = slab2;
	}
	public int getSlab3() {
		return slab3;
	}
	public void setSlab3(int slab3) {
		this.slab3 = slab3;
	}
	public float getSlab1rate() {
		return slab1rate;
	}
	public void setSlab1rate(float slab1rate) {
		this.slab1rate = slab1rate;
	}
	public float getSlab2rate() {
		return slab2rate;
	}
	public void setSlab2rate(float slab2rate) {
		this.slab2rate = slab2rate;
	}
	public float getSlab3rate() {
		return slab3rate;
	}
	public void setSlab3rate(float slab3rate) {
		this.slab3rate = slab3rate;
	}
}
